﻿namespace SchoolHRAdministrationAPI
{
    public class Class1
    {

    }
}
