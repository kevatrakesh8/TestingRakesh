﻿namespace SchoolHRAdministration
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Console.WriteLine("Hello, World!1");
        }
    }
}
